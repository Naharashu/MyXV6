#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "libc/stdint.h"

char*
fmtname(char *path)
{
  static char buf[DIRSIZ+1];
  char *p;
  int n;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
    ;
  p++;

  // Return blank-padded name.
  n = strlen(p);
  if(n >= DIRSIZ)
    return p;
  memmove(buf, p, n);
  memset(buf+n, ' ', DIRSIZ-n);
  buf[DIRSIZ] = 0;
  return buf;
}

void mode_to_string(uint16_t mode, char *out_str) {
    
    // Owner permissions
    out_str[0] = (mode & 0400) ? 'r' : '-';
    out_str[1] = (mode & 0200) ? 'w' : '-';
    out_str[2] = (mode & 0100) ? 'x' : '-';
    
    // Group permissions
    out_str[3] = (mode & 0040) ? 'r' : '-';
    out_str[4] = (mode & 0020) ? 'w' : '-';
    out_str[5] = (mode & 0010) ? 'x' : '-';
    
    // Others permissions
    out_str[6] = (mode & 0004) ? 'r' : '-';
    out_str[7] = (mode & 0002) ? 'w' : '-';
    out_str[8] = (mode & 0001) ? 'x' : '-';
    
    out_str[9] = '\0'; 
}


void
ls(char *path)
{
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;
  char* perms = malloc(10);

  if((fd = open(path, 0)) < 0){
    printf(2, "ls: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){
    printf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }

  switch(st.type){
  case T_FILE:
    printf(1, "%s %d %d %d\n", fmtname(path), st.type, st.ino, st.size);
    break;

  case T_DIR:
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
      printf(1, "ls: path too long\n");
      break;
    }
    strcpy(buf, path);
    p = buf+strlen(buf);
    *p++ = '/';
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
      if(de.inum == 0)
        continue;
      memmove(p, de.name, DIRSIZ);
      p[DIRSIZ] = 0;
      if(stat(buf, &st) < 0){
        printf(1, "ls: cannot stat %s\n", buf);
        continue;
      }
      mode_to_string(st.mode, perms);
      if(st.type == T_DIR && !(de.name[0] == '.' && (de.name[1] == '\0' || (de.name[1] == '.' && de.name[2] == '\0')))) {
        //printf(1, "/%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
        printf(1, "/%s %dB %s\n", fmtname(buf), st.size, perms);
      } else {
        printf(1, "%s %dB %s\n", fmtname(buf), st.size, perms);
      }
    }
    break;
  }
  close(fd);
}

int
main(int argc, char *argv[])
{
  int i;

  if(argc < 2){
    ls(".");
    exit();
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
  exit();
}
